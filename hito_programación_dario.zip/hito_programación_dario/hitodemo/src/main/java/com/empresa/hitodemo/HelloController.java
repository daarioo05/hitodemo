package com.empresa.hitodemo;

import com.mongodb.ConnectionString;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class HelloController {

    // Conexión a la colección MongoDB
    private MongoCollection<Document> collection;

    // Elementos de la interfaz de usuario vinculados desde el archivo FXML
    @FXML
    private TableView<Document> tableView;
    @FXML
    private TableColumn<Document, String> idColumn;
    @FXML
    private TableColumn<Document, String> nameColumn;
    @FXML
    private TableColumn<Document, String> passwordColumn;
    @FXML
    private TableColumn<Document, String> emailColumn;
    @FXML
    private TextField nameField;
    @FXML
    private TextField passwordField;
    @FXML
    private TextField emailField;

    // Método de inicialización que se ejecuta después de cargar el archivo FXML
    @FXML
    public void initialize() {
        connectToDatabase();

        // Configuración de las celdas de la tabla
        idColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getObjectId("_id").toString()));
        nameColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getString("name")));
        passwordColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getString("password")));
        emailColumn.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getString("email")));

        // Cargar datos en la tabla
        loadTableData();

        // Escuchar los cambios de selección en la tabla y cargar los datos del usuario seleccionado
        tableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                loadUserData(newSelection);
            }
        });
    }

    // Método para cargar los datos del usuario seleccionado en los campos correspondientes
    private void loadUserData(Document user) {
        nameField.setText(user.getString("name"));
        passwordField.setText(user.getString("password"));
        emailField.setText(user.getString("email"));
    }

    private void connectToDatabase() {
        try {
            var client = MongoClients.create("mongodb+srv://lector:lector@cluster0.sqineuy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0");
            MongoDatabase database = client.getDatabase("hito");
            collection = database.getCollection("usuarios");
        } catch (Exception e) {
            showAlert("Error de Conexión", "No se pudo conectar a la base de datos: " + e.getMessage());
        }
    }

    @FXML
    private void handleAdd() {
        String name = nameField.getText();
        String password = passwordField.getText();
        String email = emailField.getText();

        if (validateInput(name, password, email)) {
            try {
                // Verificar si el nombre de usuario o el correo electrónico ya existen
                Document existingUser = collection.find(new Document("$or", List.of(
                        new Document("name", name),
                        new Document("email", email)
                ))).first();

                if (existingUser != null) {
                    showAlert("Error de Validación", "El nombre de usuario o el correo electrónico ya existen.");
                    return;
                }

                // Crear el documento a insertar
                Document doc = new Document("name", name)
                        .append("password", password)
                        .append("email", email);

                // Insertar el documento en la colección
                collection.insertOne(doc);

                // Actualizar la tabla y limpiar los campos después de agregar
                loadTableData();
                clearFields();
            } catch (Exception e) {
                showAlert("Error de Base de Datos", "No se pudo agregar el registro a la base de datos.");
            }
        } else {
            showAlert("Error de Validación", "Por favor ingrese valores válidos en todos los campos.");
        }
    }

    // Método para limpiar los campos de entrada
    private void clearFields() {
        nameField.clear();
        passwordField.clear();
        emailField.clear();
    }

    // Manejo del evento de actualizar un registro existente
    @FXML
    private void handleUpdate() {
        Document selectedPerson = tableView.getSelectionModel().getSelectedItem();
        if (selectedPerson != null) {
            String name = nameField.getText();
            String password = passwordField.getText();
            String email = emailField.getText();

            if (validateInput(name, password, email)) {
                // Verificar si el nombre de usuario o el correo electrónico ya existen en otro registro
                Document existingUser = collection.find(new Document("$or", List.of(
                        new Document("name", name),
                        new Document("email", email)
                )).append("_id", new Document("$ne", selectedPerson.getObjectId("_id")))).first();

                if (existingUser != null) {
                    showAlert("Error de Validación", "El nombre de usuario o el correo electrónico ya existen.");
                    return;
                }

                // Conexión a la base de datos MongoDB
                try (var client = MongoClients.create("mongodb+srv://admin:admin@cluster0.sqineuy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")) {
                    MongoDatabase database = client.getDatabase("hito");
                    MongoCollection<Document> collection = database.getCollection("usuarios");

                    Document updatedDoc = new Document("name", name)
                            .append("password", password)
                            .append("email", email);
                    collection.updateOne(new Document("_id", selectedPerson.getObjectId("_id")), new Document("$set", updatedDoc));
                    loadTableData();
                } catch (Exception e) {
                    showAlert("Error de Base de Datos", "No se pudo actualizar el registro en la base de datos.");
                }
            } else {
                showAlert("Error de Validación", "Los datos ingresados no son válidos.");
            }
        } else {
            showAlert("Error de Actualización", "No se ha seleccionado ningún registro para actualizar.");
        }
    }

    // Manejo del evento de eliminar un registro
    @FXML
    private void handleDelete() {
        Document selectedPerson = tableView.getSelectionModel().getSelectedItem();
        if (selectedPerson != null) {
            // Conexión a la base de datos MongoDB
            try (var client = MongoClients.create("mongodb+srv://admin:admin@cluster0.sqineuy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")) {
                MongoDatabase database = client.getDatabase("hito");
                MongoCollection<Document> collection = database.getCollection("usuarios");

                collection.deleteOne(new Document("_id", selectedPerson.getObjectId("_id")));
                loadTableData();
            } catch (Exception e) {
                showAlert("Error de Base de Datos", "No se pudo eliminar el registro de la base de datos.");
            }
        } else {
            showAlert("Error de Eliminación", "No se ha seleccionado ningún registro para eliminar.");
        }
    }

    // Validación de los campos de entrada
    private boolean validateInput(String name, String password, String email) {
        if (name == null || name.trim().isEmpty()) {
            showAlert("Error de Validación", "El nombre no puede estar vacío.");
            return false;
        }
        if (password == null || password.trim().isEmpty()) {
            showAlert("Error de Validación", "La contraseña no puede estar vacía.");
            return false;
        }
        if (email == null || email.trim().isEmpty()) {
            showAlert("Error de Validación", "El correo no puede estar vacío.");
            return false;
        }
        return true;
    }

    // Cargar datos en la tabla
    private void loadTableData() {
        List<Document> persons = new ArrayList<>();
        for (Document doc : collection.find()) {
            persons.add(doc);
        }
        tableView.getItems().setAll(persons);
    }

    // Mostrar una alerta de error
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
