module com.empresa.hitodemo {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;
    requires org.mongodb.bson;
    requires org.mongodb.driver.sync.client;
    requires org.mongodb.driver.core;



    opens com.empresa.hitodemo to javafx.fxml;
    exports com.empresa.hitodemo;
}